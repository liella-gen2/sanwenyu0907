如果您想报告错误，请提供以下信息 If you want to report a bug, please provide the following information:

- [ ] 可复现问题的步骤 The steps to reproduce.
- [ ] 可复现问题的网页地址 A minimal demo of the problem via https://jsfiddle.net or http://codepen.io/pen if possible.
- [ ] 受影响的Valine版本、操作系统，以及浏览器信息 Which versions of Valine, and which browser / OS are affected by this issue?