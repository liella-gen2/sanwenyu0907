'use strict'

var Valine = require('./dist/Valine.min.js')

module.exports = Valine
module.exports.default = module.exports